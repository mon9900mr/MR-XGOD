<h1><p align="center"> IPT Mini Shell </p></h1>

## username : admin
## password : pass
<img src="https://raw.githubusercontent.com/1337r0j4n/php-backdoors/main/.img/38.jpeg">
<img src="https://raw.githubusercontent.com/1337r0j4n/php-backdoors/main/.img/39.jpeg">
