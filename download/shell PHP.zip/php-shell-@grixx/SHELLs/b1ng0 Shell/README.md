<h1 align="center">b1ng0 Shell</h1>

## password : admin
<img src="https://raw.githubusercontent.com/1337r0j4n/php-backdoors/main/.img/66.jpeg">
<img src="https://raw.githubusercontent.com/1337r0j4n/php-backdoors/main/.img/67.jpeg">
