<h1><p align="center"> Minions Cyber Crime Shells </p></h1>

## Shell user : woah
## Shell Password : peler

<img src="https://raw.githubusercontent.com/7r0j4ncodeing/Web-Shells/main/.img/16.PNG">

<img src="https://raw.githubusercontent.com/7r0j4ncodeing/Web-Shells/main/.img/17.PNG">


