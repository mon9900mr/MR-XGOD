<h1><p align="center">v3n0m WOS Shell</p></h1>

<img src="https://raw.githubusercontent.com/1337r0j4n/php-backdoors/main/.img/64.jpeg">
