<h1><p align="center"> P0wny Shell </p></h1>

<img src="https://raw.githubusercontent.com/1337r0j4n/php-backdoors/main/.img/44.jpeg">
