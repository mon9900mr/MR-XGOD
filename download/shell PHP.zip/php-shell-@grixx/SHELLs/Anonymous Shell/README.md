<h1><p align="center"> Anonymous Shell </p></h1>

## password : 123
<img src="https://raw.githubusercontent.com/1337r0j4n/php-backdoors/main/.img/28.jpeg">
<img src="https://raw.githubusercontent.com/1337r0j4n/php-backdoors/main/.img/29.jpeg">

