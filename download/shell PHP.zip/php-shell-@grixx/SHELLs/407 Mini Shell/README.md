<h1><p align="center"> 407 Mini Shell </p></h1>

## password : myshell
<img src="https://raw.githubusercontent.com/1337r0j4n/php-backdoors/main/.img/58.jpeg">
